package Redbus.com;
import java.io.IOException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import Driver.LaunchDriver;
import Driver.resusable;
import seleniumActions.seleniumUIActions;

public class registerBooking {

 	
@BeforeMethod
public static void launchurl() throws IOException {
	 LaunchDriver.readDriver("C:\\Users\\hp\\eclipse-workspace\\Selenium-Framework\\selenium_Driver\\chromedriver.exe", resusable.url1);
	
}
 @Test
 public static void contactInformation() throws IOException {
	 
	 LaunchDriver.maximizeBrowser();
	 seleniumUIActions.enterUserFirstName();
	 seleniumUIActions.enterUserLastName();
	 seleniumUIActions.enterUserPhone();
	 seleniumUIActions.enterUserEmail();
}

 @Test
 public static void mailingInformation() throws IOException {
	 
	LaunchDriver.maximizeBrowser();
	seleniumUIActions.enterMailingInformationAddress();
	seleniumUIActions.enterMailingInformationCity();
	seleniumUIActions.enterMailingInformationState();
	seleniumUIActions.enterMailingInformationpostalCode();
}

 @Test
 public static void UserInformation() throws IOException {
 
	LaunchDriver.maximizeBrowser();
	seleniumUIActions.enterUserInfoEmail();
	seleniumUIActions.enterUserInfoPassword();
	seleniumUIActions.enterUserInfoConfirmPassword();
	seleniumUIActions.enterUserInfoSubmit();
}

}
