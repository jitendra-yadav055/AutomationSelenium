package Redbus.com;
import java.io.IOException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import Driver.LaunchDriver;
import Driver.resusable;
import seleniumActions.seleniumUIActions;

public class BookingFlight{

  	
@BeforeMethod
public static void launchurl() throws IOException {
	 LaunchDriver.readDriver("C:\\Users\\hp\\eclipse-workspace\\Selenium-Framework\\selenium_Driver\\chromedriver.exe", resusable.url);
	
}
 @Test
 public static void SearchFlightData() throws IOException {
	 
	 LaunchDriver.maximizeBrowser();
	 seleniumUIActions.enterName();
	 seleniumUIActions.username();
	 seleniumUIActions.clicksignButton();
	 //LaunchDriver.closebrowser();
	
}

 @Test
 public static void bookflight() throws IOException {
	 
	 LaunchDriver.maximizeBrowser();
	 seleniumUIActions.enterName();
	 seleniumUIActions.username();
	 seleniumUIActions.clicksignButton();
	 //LaunchDriver.closebrowser();
	
}

	
	

}
