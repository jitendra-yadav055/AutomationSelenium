package readInputTestData;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class readerFile {
	
	public static String readORProperties(String xpath) throws IOException
	{
		File file = new File("C:\\Users\\hp\\Downloads\\batch47-main\\batch47-main\\Selenium_Framework\\Propertiesfile\\OR.properties");
		FileInputStream stream = new FileInputStream(file);
		Properties prop = new Properties();
		prop.load(stream);
		String readxpath = prop.getProperty(xpath);
		return readxpath;
	}

}
