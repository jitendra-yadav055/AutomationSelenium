package Driver;

public interface resusable {

	public static String url = "https://demo.guru99.com/test/login.html";
	public static String url1 = "https://demo.guru99.com/test/newtours/register.php";
}
