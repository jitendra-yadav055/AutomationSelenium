package seleniumActions;

import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import Driver.LaunchDriver;
import readInputTestData.readerFile;


public class seleniumUIActions  {
	// For  BookingFlight class xpath ORfile function
	public static void enterName() throws IOException {
		
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Gurru.Demosite.Emailaddress.input"))).sendKeys("neelam.@gmail.com");

	}
	public static void username() throws IOException {
		
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Gurru.Demosite.EmailPassword.input"))).sendKeys("Jitu@123");

	}
	public static void clicksignButton() throws IOException {
		
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Gurru.Demosite.SubmitLogin.button"))).click();

	}
	// ################################### For RegisterBooking  class xpath ORfile function ################################
	//Below one is Contact Information
	public static void enterUserFirstName() throws IOException {
		
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("contact.Information.Firstname.input"))).sendKeys("Jitendra");

	}
	public static void enterUserLastName() throws IOException {
		
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("contact.Information.lastname.input"))).sendKeys("Yadav");

	}
	public static void enterUserPhone() throws IOException {
	
	LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("contact.Information.phone.input"))).sendKeys("8080326167");

	}
	public static void enterUserEmail() throws IOException {
	
	LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("contact.Information.email.input"))).sendKeys("Jitendra.yadav055@gmail.com");

	}
	//Below one is Mailing Information
	public static void enterMailingInformationAddress() throws IOException {
		
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Mailing.Information.address.input"))).sendKeys("FilmCity");

	}
	public static void enterMailingInformationCity() throws IOException {
		
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Mailing.Information.city.input"))).sendKeys("Mumbai");

	}
	public static void enterMailingInformationState() throws IOException {
	
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Mailing.Information.state.input"))).sendKeys("Maharashtra");

	}
	public static void enterMailingInformationpostalCode() throws IOException {
	
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Mailing.Information.postalCode.input"))).sendKeys("400065");

	}
	//Below one is User Information
	public static void enterUserInfoEmail() throws IOException {
		
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("User.Information.email.input"))).sendKeys("Jitu055123@gmail.com");

	}
	public static void enterUserInfoPassword() throws IOException {
		
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("User.Information.password.input"))).sendKeys("Jitu@0011");

	}
	public static void enterUserInfoConfirmPassword() throws IOException {
	
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("User.Information.confirmPassword.input"))).sendKeys("Jitu@0011");

	}
	public static void enterUserInfoSubmit() throws IOException {
	
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("User.Information.submit.input"))).click();

	}
	
}
