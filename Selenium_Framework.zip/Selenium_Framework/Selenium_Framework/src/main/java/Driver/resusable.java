package Driver;

public interface resusable {

	public static String url = "https://demo.guru99.com/test/login.html";
}
