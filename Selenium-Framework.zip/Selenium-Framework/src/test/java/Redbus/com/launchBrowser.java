package Redbus.com;

import Driver.LaunchDriver;

public class launchBrowser extends LaunchDriver{

	public static void main(String[] args) 
	{
		LaunchDriver ld = new LaunchDriver();
		ld.readDriver("C:\\Users\\hp\\eclipse-workspace\\Selenium-Framework\\selenium_Driver\\chromedriver.exe","https://www.redbus.com/");
		
	}

}
